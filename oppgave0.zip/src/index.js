// Oppgave 1
document.getElementById("remove-btn").addEventListener("click", function () {
  document.getElementById("remove").innerHTML = "";
});

// Oppgave 2
document.getElementById("change-btn").addEventListener("click", function () {
  document.getElementById("change").innerText = "Ny tekst levert av Omar";
});

// Oppgave 3
// fikk hjelp herfra: https://codepen.io/burntcaramel/pen/YGJXAb
document.getElementById("input").addEventListener("input", function (e) {
  document.getElementById("input-text").innerText = e.target.value;
});

// Oppgave 4
// fikk hjelp av deg :D
const myList = ["item one", "item two", "item three"];

document.getElementById("write-list").addEventListener("click", function () {
  document.getElementById("ul").innerHTML = myList
    .map((para) => `<li>${para}</li>`)
    .join("");
});

// Oppgave 5
// fikk hjelp av deg :D
const text = document.getElementById("text");
const select = document.getElementById("select");

document.getElementById("create").addEventListener("click", function () {
  const html = select.value;
  const msg = text.value;
  document.getElementById(
    "placeholder"
  ).innerHTML += `<${html}>${msg}</${html}>`;
});

// Oppgave 6
// fikk hjelp av deg og
// https://www.javascripttutorial.net/javascript-dom/javascript-removechild/
const list = document.getElementById("list");

document.getElementById("remove-li").addEventListener("click", function () {
  //Vi bruker if for å stoppe å fjerne når lista er tom(false)
  if (list.lastElementChild) {
    list.removeChild(list.lastElementChild);
  }
});

// Oppgave 7
// fikk hjelp av deg
const dKnapp = document.getElementById("order");
document.getElementById("name").addEventListener("keyup", function () {
  const navn = this.value;
  if (navn && navn.length >= 4) {
    dKnapp.disabled = true;
  } else {
    dKnapp.disabled = false;
  }
});

// Oppgave 8
// nesten lik din kode, kjempe vanskelig!
const parent = document.querySelector(".children");
const children = parent.querySelectorAll("li");
document.getElementById("color").addEventListener("click", function () {
  Array.from(children).forEach((item, index) => {
    if ((index + 1) % 2 === 0) {
      item.style =
        "border: 1px solid palevioletred; margin-bottom: 5px; padding: 3px;";
    } else {
      item.style = "border: 1px solid green; margin-bottom: 5px; padding: 3px;";
    }
  });
});
